
                  <div class='row'>
                   <div class="col-sm-6"></div>
                   <div class="col-sm-6"></div>
                  </div>



                  <div class='row'>
                   <div class="col-sm-4"></div>
                   <div class="col-sm-4"></div>
                   <div class="col-sm-4"></div>
                  </div>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <div class="card card-default color-palette-bo">
        <div class="card-header">
          <div class="d-inline-block">
              <h3 class="card-title"> <i class="fa fa-plus"></i>
              <?= $title ?> </h3>
          </div>
          <div class="d-inline-block float-right">
          <!--  <a href="<?= base_url('admin/admin'); ?>" class="btn btn-success"><i class="fa fa-list"></i> <?= trans('admin_list') ?></a>
--></div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="box">
                <!-- form start -->
                <div class="box-body">
                    <?php $this->load->view('admin/includes/_messages.php') ?>
  
                    <div>

                    <style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}


.pending
{
    width: 114px;
height: 12px;
left: 520px;
top: 255px;
background: #FFF4DE;
border: 0.5px solid #FFB833;
box-sizing: border-box;
border-radius: 5px;"
}
.accepted{
    width: 114px;
height: 12px;
left: 520px;
top: 255px;
background: #E8FFCB;
border: 0.5px solid #89C440;
box-sizing: border-box;
border-radius: 5px;"
}



.rejected{
    width: 114px;
height: 12px;
left: 520px;
top: 255px;
background: #FFD6E6;
border: 0.5px solid #D93E7C;
box-sizing: border-box;
border-radius: 5px;"
}

#customers tr:nth-child(even){background-color: #f2f2f2;}


#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #36bcb1;
  color: white;
}
.singledate { 
width: 46px;
height: 26px;
left: 572px;
top: 210px;
background: #9F9BF1; border: 0.5px solid rgba(75, 74, 75, 0.15);
box-sizing: border-box;
border-radius: 25px; 
}
</style>


<?php echo form_open_multipart(base_url('admin/shift/view'), 'class="form-horizontal"');  ?> 
                  

<?php 

$array=array(
    //array('label'=>'participant_name','required'=>'requdddired','name'=>'participant_name','type'=>'text', 'value'=>''),
    array('label'=>'','name'=>'from','required'=>'requirded','type'=>'date', 'value'=>@$from),
    );
    echo create_formb($array);
?>



                  <!-------->
                  <div class='row'>

<div class="col-md-6">

<div class="form-group">
  <input type="submit" name="submit" value="<?= trans('Serch Data') ?>" class="btn btn-primary pull-right">
  </div>
              </div>
  <div class="col-md-6">

</div>
      </div>
      <?php echo form_close(); ?>


<table id="customers">
  <tr>
    <th>Participant</th>

    <th>

    <?= date('D', strtotime($from));?>   <span class="singledate"> <?= date('d', strtotime($from));?> 
    </span>

 </th>
    <th>
    <?= date('D', strtotime($from . ' +1 day'));?>   <span class="singledate"> <?= date('d', strtotime($from . ' +1 day'));?> 
    </span>

    </th>
    <th>   <?= date('D', strtotime($from . ' +2 day'));?>   <span class="singledate"> <?= date('d', strtotime($from . ' +2 day'));?> 
    </span>
</th> 
    <th>   <?= date('D', strtotime($from . ' +3 day'));?>   <span class="singledate">  <?= date('d', strtotime($from . ' +3 day'));?> 
    </span>
</th>
    <th>   <?= date('D', strtotime($from . ' +4 day'));?>    <span class="singledate">  <?= date('d', strtotime($from . ' +4 day'));?> 
    </span>
</th>
    <th>   <?= date('D', strtotime($from . ' +5 day'));?>   <span class="singledate">  <?= date('d', strtotime($from . ' +5 day'));?> 
    </span>
</th>
    <th>  <?= date('D', strtotime($from . ' +6 day'));?>  <span class="singledate">  <?= date('d', strtotime($from . ' +6 day'));?> 
    </span>
</th>

  </tr>

<?php
  $participant=select('participant');
  
  ?>
  <?php
           foreach($participant as $p) {  
           ?>
  <tr>


    <td> 
      <img src="<?=base_url()?>/uploads/<?=$p['photo']?>"  class="img-circle" alt="" border="3" 
    height="50" width="50"> <?=$p['first_name']?>  <?=$p['last_name']?> 
  
  </td>



 <td>
<?php 
$rr=get_shift($p['id'],date('Y-m-d', strtotime($from)));
if(isset($rr) AND !empty($rr))
{ 
    foreach($rr as $r) {
    ?>
<span class='<?=$r['class']?>' 
data-toggle="modal"  data-target="#myModal<?=$r['shift_id']?>" > <?=$r['shift_start']?>-<?=$r['shift_end']?> </span> <br>
<?php
}
}
?>
 </td>

<td> 
 <?php $rr=(get_shift($p['id'],date('Y-m-d', strtotime($from. ' +1 day')))); 

 if(isset($rr) AND !empty($rr))
{ 
    foreach($rr as $r) {
    ?>
<span class='<?=$r['class']?>'
 data-toggle="modal" data-target="#myModal<?=$r['shift_id']?>"> <?=$r['shift_start']?> -<?=$r['shift_end']?></span> <br>
<?php
}
}
?>
</td>

    <td> 
    <?php $rr=(get_shift($p['id'],date('Y-m-d', strtotime($from. ' +2 day')))); 
    
if(isset($rr) AND !empty($rr))
{ 
    foreach($rr as $r) {
    ?>
<span class='<?=$r['class']?>' 
 data-toggle="modal" data-target="#myModal<?=$r['shift_id']?>" > <?=$r['shift_start']?> -<?=$r['shift_end']?></span> <br>
<?php
}
}
?>

</td>
    <td> 
    <?php $rr=(get_shift($p['id'],date('Y-m-d', strtotime($from. ' +3 day')))); 
    
if(isset($rr) AND !empty($rr))
{ 
    foreach($rr as $r) {
    ?>
<span class='<?=$r['class']?>' data-toggle="modal"
 data-target="#myModal<?=$r['shift_id']?>"> <?=$r['shift_start']?> -<?=$r['shift_end']?> </span> <br>
<?php
}
}
?>

</td>
    <td> 
    <?php $rr=(get_shift($p['id'],date('Y-m-d', strtotime($from. ' +4 day')))); 
    
if(isset($rr) AND !empty($rr))
{ 
    foreach($rr as $r) {
    ?>
<span class='<?=$r['class']?>'  
 data-toggle="modal"
data-target="#myModal<?=$r['shift_id']?>"> <?=$r['shift_start']?> -<?=$r['shift_end']?></span> <br>
<?php
}
}
?>

</td>

    <td> 
    <?php $rr=(get_shift($p['id'],date('Y-m-d', strtotime($from. ' +5 day')))); 
    
if(isset($rr) AND !empty($rr))
{ 
    foreach($rr as $r) {
    ?>
<span class='<?=$r['class']?>'  
 data-toggle="modal"
data-target="#myModal<?=$r['shift_id']?>"> <?=$r['shift_start']?> -<?=$r['shift_end']?></span> <br>
<?php
}
}
?>

</td>


    <td> 
    <?php $rr=(get_shift($p['id'],date('Y-m-d', strtotime($from. ' +6 day')))); 
    
if(isset($rr) AND !empty($rr))
{ 
    foreach($rr as $r) {
    ?>
<span class='<?=$r['class']?>'   
 data-toggle="modal"
data-target="#myModal<?=$r['shift_id']?>"> <?=$r['shift_start']?> -<?=$r['shift_end']?></span> <br>

<?php
}
}
?>

</td>


  </tr> 
  <?php } ?>
</table>






</div>


















                  </div>
<!-- /.box-body -->

</div>
</div>
</div>  
</div>
</div>
</section> 
</div>


<?php  
foreach(select('shift') as $sh) 
{
  //PRINT_R($sh);
?>
<!-- Modal -->
<div id="myModal<?=$sh['id']?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
       
      </div>
      <div class="modal-body">
        
  <?php  
   if($sh['status']==1)
    {
      $status='Shift Confirmed';
      $class='accepted';
     ?>
 <center>
 <h3><?=$status?></h3>
<h5>
Participant Name <br>
  <?php echo $this->db->get_where('participant',array('id'=>$sh['participant']))->row()->first_name?> <?php echo $this->db->get_where('participant',array('id'=>$sh['participant']))->row()->last_name?>
</h5>


<h5> Employee<br>
  <?php echo $this->db->get_where('ci_admin',array('admin_id'=>$sh['employee']))->row()->firstname?>  
  <?php echo $this->db->get_where('ci_admin',array('admin_id'=>$sh['employee']))->row()->firstname?> 
  </h5>

<h5> Allowances<br>
  <?php echo $this->db->get_where('allowance',array('id'=>$sh['allowances']))->row()->name?> 
  </h5>

  <h5> Shift Location <br>
  <?php echo $sh['shift_location'];?> 
  <?php if($sh['other_location']!='')
  {  ?>
  <br>
  Other Location <br>
  <?php echo $sh['other_location']?>
  <?php } ?>
  </h5>


  <h5> Employee Pay Rate <br>
  <?php echo $this->db->get_where('emppay_guide',array('id'=>$sh['pay_rate']))->row()->hourly_rate?> Per Hours
  </h5>



</center>
<?php 
    
    
    }
   
   ?>





<?php  
   if($sh['status']==0)
    {
      $status='Awaiting confirmation';
      $class='accepted';
     ?>
 <center>
 <h3><?=$status?></h3>
<h5>
Participant Name <br>
  <?php echo $this->db->get_where('participant',array('id'=>$sh['participant']))->row()->first_name?> <?php echo $this->db->get_where('participant',array('id'=>$sh['participant']))->row()->last_name?>
</h5>

<h5> Employee<br>
  <?php echo $this->db->get_where('ci_admin',array('admin_id'=>$sh['employee']))->row()->firstname?>  
  <?php echo $this->db->get_where('ci_admin',array('admin_id'=>$sh['employee']))->row()->firstname?> 
  </h5>
<h5> Allowances<br>
  <?php echo $this->db->get_where('allowance',array('id'=>$sh['allowances']))->row()->name?> 
  </h5>

  <h5> Shift Location <br>
  <?php echo $sh['shift_location'];?> 
  <?php if($sh['other_location']!='')
  {  ?>
  <br>
  Other Location <br>
  <?php echo $sh['other_location']?>
  <?php } ?>
  </h5>


  <h5> Employee Pay Rate <br>
  <?php echo $this->db->get_where('emppay_guide',array('id'=>$sh['pay_rate']))->row()->hourly_rate?> Per Hours
  </h5>
  <a href="<?=base_url()?>/admin/shift/edit/<?=$sh['id']?>" class='btn btn-info'>Edit</a>
  </center>
   <?php 
    }
   ?>



<?php  
   if($sh['status']==2)
    {
      $status='Shift Rejected';
      $class='accepted';
     ?>
 <center>
 <h3><?=$status?></h3>


 <h5> 
  The shift was rejected by the employee for the following reason:
    <br>
    <?php echo $sh['rejected_reson'];?> 
    </h5>


    

 <h5>
Participant Name <br>
  <?php echo $this->db->get_where('participant',array('id'=>$sh['participant']))->row()->first_name?> <?php echo $this->db->get_where('participant',array('id'=>$sh['participant']))->row()->last_name?>
</h5>

<h5> Employee<br>
  <?php echo $this->db->get_where('ci_admin',array('admin_id'=>$sh['employee']))->row()->firstname?>  
  <?php echo $this->db->get_where('ci_admin',array('admin_id'=>$sh['employee']))->row()->firstname?> 
  </h5>

<h5> Allowances<br>
  <?php echo $this->db->get_where('allowance',array('id'=>$sh['allowances']))->row()->name?> 
  </h5>


  <h5> Shift Location <br>
  <?php echo $sh['shift_location'];?> 
  <?php if($sh['other_location']!='')
  {  ?>
  <br>
  Other Location <br>
  <?php echo $sh['other_location']?>
  <?php } ?>
  </h5>


  <h5> Employee Pay Rate <br>
  <?php echo $this->db->get_where('emppay_guide',array('id'=>$sh['pay_rate']))->row()->hourly_rate?> Per Hours
  </h5>

  <a href="<?=base_url()?>/admin/shift/request_again/<?=$sh['id']?>" class='btn btn-info'>Request again</a>
  

  <a href="<?=base_url()?>/admin/shift/ressign/<?=$sh['id']?>" class='btn btn-info' style='background:#6A2875;'>Reassign</a>
  



  </center>
   <?php 
    }
   ?>




      </div>
      <div class="modal-footer">

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<?php  } ?>