
                  <div class='row'>
                   <div class="col-sm-6"></div>
                   <div class="col-sm-6"></div>
                  </div>



                  <div class='row'>
                   <div class="col-sm-4"></div>
                   <div class="col-sm-4"></div>
                   <div class="col-sm-4"></div>
                  </div>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <div class="card card-default color-palette-bo">
        <div class="card-header">
          <div class="d-inline-block">
              <h3 class="card-title"> <i class="fa fa-plus"></i>
              <?= $title ?> </h3>
          </div>
          <div class="d-inline-block float-right">
          <!--  <a href="<?= base_url('admin/admin'); ?>" class="btn btn-success"><i class="fa fa-list"></i> <?= trans('admin_list') ?></a>
--></div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="box">
                <!-- form start -->
                <div class="box-body">

                  <!-- For Messages -->
                  <?php $this->load->view('admin/includes/_messages.php') ?>

                  <?php echo form_open_multipart(base_url('admin/shift/add'), 'class="form-horizontal"');  ?> 
                  


                  <?php 

$participant=select('participant');
                  ?>

<div class="row">
      <div class="col-sm-4"><label for="firstname" class="col-md-12 control-label">participant_name</label>
      </div>
      <div class="col-sm-4">
     <div class="form-group">
      <div class="col-md-4">
        <select name="participant" requiredd="" class="form-control participant_name" id="select">
          <option value="">Please Select value</option>
         
         <?php
           foreach($participant as $rate) {  
           ?>
         <option value="<?=$rate['id']?>"><?=$rate['first_name']?> <?=$rate['last_name']?></option>
          <?php } ?>
        </select>
      </div>

      </div>
      
      </div> 
       <div class="col-sm-2">
       
               

       </div>
      
       
      <div class="col-sm-2">
      

      </div>
     
      </div>



                  <?php 
                  $allowance=select('allowance');
                  $employee_pay_rate=select('emppay_guide');
                  $emp=select('ci_admin',array('admin_role_id'=>7));
                  $dropdown=array(array('id'=>'Yes','name'=>'Yes'),array('id'=>'No','name'=>'No'));





                  $array=array(
                  //array('label'=>'participant_name','required'=>'requdddired','name'=>'participant_name','type'=>'text', 'value'=>''),
                  array('label'=>'date','name'=>'date','required'=>'requirded','type'=>'date', 'value'=>''),
                  );
                  echo create_formb($array);

?>

<div class="row">
                  <div class="col-sm-4">
                  <label for="firstname" class="col-md-12 control-label">shift_start</label>
                  </div>
                  <div class="col-md-4">
                  <div class="form-group">
                  <input type="time" value="" reqduired="" name="shift_start" class="form-control shift_start" id="time" placeholder="shift_start">
                  </div>
                  </div>
                  <div class="col-sm-4"></div>
                  
                  </div>



                  <div class="row">
                  <div class="col-sm-4">
                  <label for="firstname" class="col-md-12 control-label">shift_end</label>
                  </div>
                  <div class="col-md-4">
                  <div class="form-group">
                  <input type="time" value="" reqduired="" name="shift_end" class="form-control shift_end" id="time" placeholder="shift_end">
                  </div>
                  </div>
                  <div class="col-sm-4"></div>
                  
                  </div>


<?php

                  
                  $array=array(
                    //array('label'=>'participant_name','required'=>'requdddired','name'=>'participant_name','type'=>'text', 'value'=>''),
                  array('label'=>'shift_type','name'=>'shift_type','type'=>'text','required'=>'requdired', 'value'=>''),
                  //array('label'=>'create_a_split_shift','name'=>'create_a_split_shift','type'=>'select', 'dropdown'=>$dropdown,'required'=>'requdired', 'value'=>''),
                  array('label'=>'allowances','name'=>'allowances','type'=>'select','dropdown'=>$allowance, 'required'=>'rsequired','value'=>''),
                  array('label'=>'shift_location','name'=>'shift_location','type'=>'text','required'=>'requiredd', 'value'=>''),
                  array('label'=>'other_location','name'=>'other_location','type'=>'text','required'=>'requiredd', 'value'=>''),
                  //array('label'=>'select_employee','name'=>'select_employee','type'=>'select','required'=>'requiredd','dropdown'=>$emp, 'check_val'=>'admin_id','value'=>''),
                
                  );
                 echo create_formb($array);
               ?>



<div class="row">
      <div class="col-sm-4"><label for="firstname" class="col-md-12 control-label">select_employee</label>
      </div>
      <div class="col-sm-4">
     <div class="form-group">
      <div class="col-md-4">
        <select name="employee" requiredd="" class="form-control select_employee" id="select">
          <option value="">Please Select value</option>
         
         <?php
           foreach($emp as $rate) {  
           ?>
         <option value="<?=$rate['admin_id']?>"><?=$rate['firstname']?> <?=$rate['lastname']?></option>
          <?php } ?>
        </select>
      </div>

      </div>
      
      </div> 
       <div class="col-sm-2">
       
               

       </div>
      
       
      <div class="col-sm-2">
      

      </div>
     
      </div>







<div class="row">
      
      <div class="col-sm-4"><label for="firstname" class="col-md-12 control-label">employee_pay_rate</label>
      </div>
      <div class="col-sm-4">
     <div class="form-group">
      <div class="col-md-4">
        <select name="pay_rate" requiredd="" class="form-control employee_pay_rate" id="select">
          <option value="">Please Select value</option>
         
         <?php
           foreach($employee_pay_rate as $rate) {  
           ?>
         <option value="<?=$rate['id']?>"><?=$rate['hourly_rate']?>(Hourly Rate)</option>
          <?php } ?>
        </select>
      </div>

      </div>
      
      </div> 
       <div class="col-sm-2">
       


       </div>
      
       
       <div class="col-sm-2">
       

       </div>
      
       </div>







                  <!-------->
                 <div class='row'>

<div class="col-md-6">
              </div>
  <div class="col-md-6">

  <div class="form-group">
  <input type="submit" name="submit" value="<?= trans('Add Split Shift') ?>" class="btn btn-primary pull-right">
  </div>
</div>
      </div>
      <?php echo form_close(); ?>

    </div>
<!-- /.box-body -->
</div>
</div>
</div>  
</div>
</div>
</section> 
</div>